export const data = ["learn react native", "learn typeScript"];
